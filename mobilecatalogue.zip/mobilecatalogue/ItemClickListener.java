package com.example.nj84616.mobilecatalogue;

import android.view.View;


public interface ItemClickListener {

    void onItemClick(View view, int position);
}

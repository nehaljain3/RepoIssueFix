package com.example.nj84616.mobilecatalogue.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by nehal on 29/08/18.
 */

public class MVP implements Parcelable {
    @SerializedName("backgroundColor")
    @Expose
    private String backgroundColor;
    @SerializedName("foregroundColor")
    @Expose
    private String foregroundColor;
    @SerializedName("ftrBGColor")
    @Expose
    private String ftrBGColor;
    @SerializedName("ftrFGColor")
    @Expose
    private String ftrFGColor;
    @SerializedName("icon")
    @Expose
    private String icon;
    @SerializedName("title")
    @Expose
    private String title;

    public MVP(){

    }
    public MVP(Parcel in) {
        backgroundColor = in.readString();
        foregroundColor = in.readString();
        ftrBGColor = in.readString();
        ftrFGColor = in.readString();
        icon = in.readString();
        title = in.readString();
    }

    public static final Creator<MVP> CREATOR = new Creator<MVP>() {
        @Override
        public MVP createFromParcel(Parcel in) {
            return new MVP(in);
        }

        @Override
        public MVP[] newArray(int size) {
            return new MVP[size];
        }
    };

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public String getForegroundColor() {
        return foregroundColor;
    }

    public void setForegroundColor(String foregroundColor) {
        this.foregroundColor = foregroundColor;
    }

    public String getFtrBGColor() {
        return ftrBGColor;
    }

    public void setFtrBGColor(String ftrBGColor) {
        this.ftrBGColor = ftrBGColor;
    }

    public String getFtrFGColor() {
        return ftrFGColor;
    }

    public void setFtrFGColor(String ftrFGColor) {
        this.ftrFGColor = ftrFGColor;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(backgroundColor);
        parcel.writeString(foregroundColor);
        parcel.writeString(ftrBGColor);
        parcel.writeString(ftrFGColor);
        parcel.writeString(icon);
        parcel.writeString(title);
    }
}




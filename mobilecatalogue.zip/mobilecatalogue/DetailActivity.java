package com.example.nj84616.mobilecatalogue;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.nj84616.mobilecatalogue.home.MobileCatalogUtils;
import com.example.nj84616.mobilecatalogue.model.CommonModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity implements IClickCallback {

    private RecyclerView rvDetailActivity;

    private static ArrayList<CommonModel> detailScreenData;

    private String fontColor;

    private String backgroundColor;

    private static RecyclerView.Adapter adapter;

    private RecyclerView.LayoutManager layoutManager;

    private Toolbar mToolbar;

    private LinearLayout llDetailActivity;

    private int position;

    private TextView tbTitle;

    private String mvpTitle;

    private LinearLayout llTbDetail;

    private TextView tbTitleModule;

    private int currentlySelectedItemPosition = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);

        mToolbar = findViewById(R.id.tb_detail_activity);

        mToolbar.setPadding(0,0,0,0);//for tab otherwise give space in tab
        mToolbar.setContentInsetsAbsolute(0,0);
        tbTitle = findViewById(R.id.tb_title);

        tbTitleModule = findViewById(R.id.tb_title_specific);

        setSupportActionBar(mToolbar);
        tbTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        rvDetailActivity = findViewById(R.id.rv_detail_activity);

        layoutManager = new LinearLayoutManager(this);

        rvDetailActivity.setLayoutManager(layoutManager);

        llDetailActivity = findViewById(R.id.ll_detail_activity);


        if (getIntent().getExtras()!= null)
        position = getIntent().getExtras().getInt("position");
        backgroundColor = getIntent().getExtras().getString("background_color");
        fontColor = getIntent().getExtras().getString("font_color");
        mvpTitle = getIntent().getExtras().getString("title");

        tbTitle.setText((getString(R.string.mvp_title)+ "    "));
        tbTitleModule.setText(mvpTitle);


        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(Color.parseColor("#" + (backgroundColor)));
        }

        //load JSON here


        loadData(position);


    }


    private void loadData(int position) {

        detailScreenData = new ArrayList<>();

        try {
            switch (position){
                case 0 :
                    loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                    llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));

                    break;
                case 1 :
                    loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                    llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));
                    break;
                case 2:
                    loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                    llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));
                    break;
                    case 3 :
                        loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                        llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));
                        break;
                case 4:
                    loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                    llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));
                    break;
                case 5:
                    loadDataFromAssets(new JSONObject(MobileCatalogUtils.loadJSONFromAsset(DetailActivity.this,position)),position);
                    llDetailActivity.setBackgroundColor(Color.parseColor("#" + (backgroundColor)));
                    break;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        adapter = new DetailRecyclerViewAdapter(this, detailScreenData, fontColor, DetailActivity.this);
        rvDetailActivity.setAdapter(adapter);
    }



    private void loadDataFromAssets(JSONObject jsonObject, int position) {

        JSONArray jsonArray = new JSONArray();
        try{
            switch (position){

                case 0:
                    jsonArray = jsonObject.getJSONArray("Borrow");
                    break;
                case 1:
                    jsonArray = jsonObject.getJSONArray("Invest");
                    break;
                case 2:
                    jsonArray = jsonObject.getJSONArray("Information");
                    break;
                case 3:
                    jsonArray = jsonObject.getJSONArray("Pay");
                    break;
                case 4 :
                    jsonArray = jsonObject.getJSONArray("Identify");
                    break;
                case 5:
                    jsonArray = jsonObject.getJSONArray("Enable");
                    break;

            }

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        for(int i =0; i<jsonArray.length(); i++){
            CommonModel commonModel = new CommonModel();
            try{
                commonModel.setName(jsonArray.getJSONObject(i).getString("name"));
                commonModel.setPlatform(jsonArray.getJSONObject(i).getString("platform"));
                commonModel.setVideoList(jsonArray.getJSONObject(i).getString("video"));
                commonModel.setDetail(jsonArray.getJSONObject(i).getString("detail"));

                detailScreenData.add(commonModel);
            }catch (JSONException e){
                e.printStackTrace();
            }

        }

    }


    @Override
    public void OnItemClick(int position) {

        if (rvDetailActivity.getLayoutManager() != null) {

            if (currentlySelectedItemPosition != -1 && position != currentlySelectedItemPosition) {
                adapter.notifyItemChanged(currentlySelectedItemPosition);
            }

            View view = rvDetailActivity.getLayoutManager().findViewByPosition(position);
            RelativeLayout rlChild = view.findViewById(R.id.rl_detail_child_layout);

            if (position == currentlySelectedItemPosition) {
                if (rlChild.getVisibility() == View.VISIBLE) {
                    adapter.notifyItemChanged(currentlySelectedItemPosition);
                } else {
                    showDetailedView(rlChild);
                }
            } else {
                showDetailedView(rlChild);
            }

            currentlySelectedItemPosition = position;
        }

    }

    private void showDetailedView(RelativeLayout rlChild) {
        rlChild.setVisibility(View.VISIBLE);
        //ivUpArrow.setImageResource(R.mipmap.up_arrow);
        //setAnimationOfArrow(ivUpArrow, position);
        setDownAnimationOfChild(rlChild, position);
    }


    private void setDownAnimationOfChild(View view, int lastPosition){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.slide_down);
        view.startAnimation(animation);
    }

    private void setUpAnimationOfChild(View view, int lastposition){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.slide_up);
        view.startAnimation(animation);
    }

    private void setAnimationOfArrow(View view, int lastPosition){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        view.startAnimation(animation);
    }
}

package com.example.nj84616.mobilecatalogue;

/**
 * Created by nehal on 29/08/18.
 */

public class JsonConstants {

    public static final String MVP = "backgroundColor";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    public static final String FIVE = "5";

    public static final String BACKGROUND_COLOR = "backgroundColor";
    public static final String FOREGROUND_COLOR = "foregroundColor";
    public static final String FTRBGCOLOR = "backgroundColor";
    public static final String FTRFGCOLOR = "backgroundColor";
    public static final String ICON = "backgroundColor";
    public static final String TITLE = "backgroundColor";

}

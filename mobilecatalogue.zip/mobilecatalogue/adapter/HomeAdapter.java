package com.example.nj84616.mobilecatalogue.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.nj84616.mobilecatalogue.DetailActivity;
import com.example.nj84616.mobilecatalogue.ItemClickListener;
import com.example.nj84616.mobilecatalogue.R;

import com.example.nj84616.mobilecatalogue.model.MVP;


import java.util.ArrayList;

/**
 * Created by nehal on 28/08/18.
 */

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ViewHolder> {

    private ArrayList<MVP> data;
    private Context mContext;


    public HomeAdapter(Context mContext, ArrayList<MVP> data) {
        this.mContext = mContext;
        this.data = data;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.items_home, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {


        CardView cardView = holder.cardView;
        TextView tvItemTitle = holder.tvItemName;
        ImageView ivItemImage = holder.ivItemImage;


        for(int i = 1; i <= data.size(); i++){

            String backgroundColor = "#" + data.get(position).getBackgroundColor();

            cardView.setCardBackgroundColor(Color.parseColor(backgroundColor));

            tvItemTitle.setText(data.get(position).getTitle());

            if(data.get(position).getIcon().equalsIgnoreCase("Borrow")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.borrow)));
            }
            else if(data.get(position).getIcon().equalsIgnoreCase("Invest")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.invest)));
            }
            else if(data.get(position).getIcon().equalsIgnoreCase("Information")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.information)));
            }
            else if(data.get(position).getIcon().equalsIgnoreCase("Transactions")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.transactions)));
            }
            else if(data.get(position).getIcon().equalsIgnoreCase("Security")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.security)));
            }
            else if(data.get(position).getIcon().equalsIgnoreCase("Services")){
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.services)));
            }
            else {
                ivItemImage.setImageDrawable(ContextCompat.getDrawable(mContext,(R.mipmap.borrow)));
            }
        }


        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Intent intent = new Intent(mContext, DetailActivity.class);
                        intent.putExtra("position",position);
                        intent.putExtra("title",data.get(position).getTitle());
                        intent.putExtra("background_color",data.get(position).getFtrBGColor());
                    intent.putExtra("font_color",data.get(position).getFtrFGColor());
                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener  {

        CardView cardView;
        TextView tvItemName;
        ImageView ivItemImage;
        private ItemClickListener itemClickListener;

        private ViewHolder(View itemView) {

            super(itemView);

            cardView = itemView.findViewById(R.id.cv_dashboard);
            tvItemName = itemView.findViewById(R.id.tv_dashboard_item);
            ivItemImage = itemView.findViewById(R.id.iv_dashboard_item);

            cardView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemClick(v,getLayoutPosition());

        }

        public void setItemClickListener(ItemClickListener ic)
        {
            this.itemClickListener=ic;

        }
    }

}
